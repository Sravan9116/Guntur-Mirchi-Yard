package com.example.RegisterLogin1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterLogin1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
