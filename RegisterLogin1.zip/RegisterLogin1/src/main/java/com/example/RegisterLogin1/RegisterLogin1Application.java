package com.example.RegisterLogin1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterLogin1Application {

	public static void main(String[] args) {
		SpringApplication.run(RegisterLogin1Application.class, args);
	}

}
